# Agent Starter Paket für Claude Code

Mit diesem Paket baut dir Claude Code in etwa einer Stunde dein eigenes KI Team: eine Identität, die weiß, wer du bist und wie du schreibst, einen Orchestrator, der Aufgaben verteilt, Spezialisten für Code, Texte, E-Mails, Recherche, Planung und mehr, eine Skill Bibliothek und ein Dashboard, auf dem du alles auf einen Blick siehst.

Alles wird auf dich zugeschnitten. Claude stellt dir dafür am Anfang ein paar Fragen.

## In 4 Schritten

1. **Claude Code installieren.** Desktop App oder Terminal, beides geht. Du brauchst ein Claude Konto mit Pro oder Max Abo (oder API Zugang).
2. **Diesen Ordner an einen festen Ort legen** und umbenennen, zum Beispiel `Mein Agent System` in deinen Dokumenten.
3. **Claude Code in diesem Ordner öffnen.** In der Desktop App den Ordner auswählen. Im Terminal in den Ordner wechseln und `claude` eingeben.
4. **`STARTER_PROMPT.txt` öffnen, alles kopieren, in Claude Code einfügen, Enter.** Dann die Fragen beantworten und den Plan bestätigen.

## Was in diesem Paket liegt

| Datei | Wofür |
|-------|-------|
| `STARTER_PROMPT.txt` | Der Bauplan. Einmal komplett einfügen. |
| `FOLGEPROMPTS.md` | Kurze Prompts für später: neuer Agent, neuer Skill, Dashboard, Systemcheck. |
| `vorlagen/` | Vorlagen, nach denen Claude alle Agenten und Skills anlegt. |
| `dashboard/` | Fertiges Dashboard. Öffnet sich per Doppelklick auf `index.html`. |

## Gut zu wissen

- Claude fragt um Erlaubnis, bevor es Dateien anlegt oder Befehle ausführt. Das ist normal. Lies kurz mit und bestätige.
- Nach dem Bau Claude Code **einmal neu starten**, damit die neuen Agenten geladen werden.
- Das Dashboard aktualisierst du mit dem Satz: `Aktualisiere das Dashboard`.
- Schreib niemals Passwörter, API Keys oder Bankdaten in die Dateien. Die gehören in eine `.env` Datei.
- Fang klein an. Gib deinem Team erst einfache Aufgaben und schärfe dann die Agenten nach, die du am meisten nutzt.
