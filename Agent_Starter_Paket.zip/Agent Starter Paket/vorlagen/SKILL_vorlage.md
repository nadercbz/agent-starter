---
name: beispiel-skill
description: Nutze diesen Skill, wenn ich [Aufgabe] brauche. Typische Formulierungen von mir sind "schreib mir ...", "verbessere ...", "plane ...". Nicht nutzen für [Abgrenzung].
---

# Titel des Skills

> Die description oben ist das Wichtigste an der ganzen Datei. Claude erkennt daran, wann dieser Skill gebraucht wird.
> Sie steht in EINER Zeile, beginnt mit "Nutze diesen Skill, wenn ..." und nennt Beispielsätze.
> name = Ordnername, klein geschrieben, mit Bindestrich getrennt, zum Beispiel cold-email.

## Wann nutzen und wann nicht

- Nutzen: konkrete Situationen
- Nicht nutzen: Abgrenzung zu anderen Skills

## Vorab klären

Nur fragen, was nicht schon aus Soul oder dem Projekt bekannt ist. Höchstens 4 Fragen.

1. Frage 1
2. Frage 2

## Prinzipien

- Prinzip 1, konkret und prüfbar
- Prinzip 2

## Ablauf

1. Schritt 1
2. Schritt 2
3. Schritt 3

## Output Format

So sieht das Ergebnis aus: Aufbau, Länge, Dateiname, Ablageort.

## Beispiel

Ein kurzes, echtes Beispiel für Eingabe und Ergebnis.

## Verwandte Skills

- anderer-skill: wann stattdessen
