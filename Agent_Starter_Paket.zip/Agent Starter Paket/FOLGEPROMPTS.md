# Folgeprompts

Kurze Prompts für die Zeit nach dem Aufbau. Kopieren, die Stellen in Großbuchstaben ersetzen, einfügen.

## 1. Neuen Agenten anlegen

```
Lege einen neuen Agenten an. Name: NAME. Aufgabe: WAS ER FÜR MICH ERLEDIGEN SOLL. Nutze den Skill neuer-agent: nächste freie Nummer, AGENT.md und Subagent Datei aus vorlagen/, passende Skills zuordnen oder neu anlegen, AGENTS.md und CLAUDE.md aktualisieren, Dashboard neu bauen. Stell mir vorher höchstens 3 Fragen.
```

## 2. Neuen Skill anlegen

```
Lege einen neuen Skill an. Thema: THEMA. Ordne ihn dem Agenten AGENT zu. Nutze den Skill neuer-skill und die Vorlage vorlagen/SKILL_vorlage.md. Die description muss genau beschreiben, wann der Skill gebraucht wird. Baue danach das Dashboard neu.
```

Tipp: Hast du eine Anleitung, einen Text oder ein PDF, aus dem der Skill entstehen soll, hänge es an und schreib dazu: `Leite den Ablauf aus dieser Datei ab.`

## 3. Dashboard aktualisieren

```
Aktualisiere das Dashboard. Führe dashboard/build_dashboard.py aus, zeig mir alle Hinweise und behebe, was sich ohne Rückfrage beheben lässt. Öffne danach dashboard/index.html.
```

## 4. Systemcheck

```
Mach einen Systemcheck mit WatchTower und dem Skill system-check. Prüfe: jeder Agent in Agents/ und in .claude/agents vorhanden, jeder Skill mit description, keine toten Verweise, AGENTS.md gleich Ordnerstand, CLAUDE.md schlank, keine Passwörter oder Schlüssel in Dateien. Gib mir eine kurze Liste mit Befund und Vorschlag.
```

## 5. Neues Projekt anlegen

```
Lege ein neues Projekt an: NAME. Ziel: ZIEL. Nutze Projects/_Vorlage, nächste freie Nummer. Schreib die kleine CLAUDE.md im Projektordner mit Ziel, Stand und nächsten Schritten. Trage das Projekt in die Workspace Map in CLAUDE.md ein.
```

## 6. Teamaufgabe über Brain

```
Brain, verteile diese Aufgabe auf das Team: AUFGABE. Zeig mir zuerst kurz, welcher Agent welchen Schritt übernimmt, dann leg los. Prüfe das Ergebnis am Ende gegen Soul.
```

## 7. Agent nachschärfen

```
Der Agent NAME trifft meinen Stil noch nicht. Hier ist ein Beispiel, wie es sein soll: BEISPIEL. Passe seine AGENT.md und den passenden Skill an, damit das künftig so rauskommt. Zeig mir vorher die Änderungen.
```
