#!/usr/bin/env python3
"""
Liest dein Agent System ein und schreibt dashboard/data.js.

Aufruf (im Hauptordner deines Systems):
    python3 dashboard/build_dashboard.py

Was gelesen wird:
    Agents/*/AGENT.md            Kopfblock (Frontmatter) mit nummer, name, rolle, layer, status, skills
    .claude/skills/*/SKILL.md    Kopfblock mit name und description
    .claude/agents/*.md          Die schlanken Subagent Dateien (nur zum Abgleich)

Nur Standardbibliothek, keine Installation noetig.
"""

import json
import re
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent / "data.js"

# Diese Agenten brauchen keine Subagent Datei (sie laufen als Rolle der Hauptsitzung)
OHNE_SUBAGENT = {"soul", "brain"}


def parse_frontmatter(text):
    """Sehr einfacher Kopfblock Parser: Zeilen 'schluessel: wert' zwischen zwei '---'."""
    data = {}
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return data, text
    end = None
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            end = i
            break
    if end is None:
        return data, text
    for line in lines[1:end]:
        m = re.match(r"^([A-Za-z_][\w]*)\s*:\s*(.*)$", line)
        if m:
            value = m.group(2).strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
                value = value[1:-1]
            data[m.group(1).lower()] = value
    return data, "\n".join(lines[end + 1:])


def split_list(value):
    if not value:
        return []
    value = value.strip().strip("[]")
    return [p.strip().strip("\"'") for p in re.split(r"[,;]", value) if p.strip()]


def first_heading(body):
    for line in body.splitlines():
        if line.startswith("#"):
            return line.lstrip("# ").strip()
    return ""


def rel(p):
    return p.relative_to(ROOT).as_posix()


def read(p):
    try:
        return p.read_text(encoding="utf-8")
    except Exception as exc:  # pragma: no cover
        print(f"Warnung: {p} nicht lesbar ({exc})")
        return ""


def main():
    warnings = []

    # ---------- Agenten ----------
    agents = []
    for f in sorted((ROOT / "Agents").glob("*/AGENT.md")):
        fm, body = parse_frontmatter(read(f))
        folder = f.parent.name
        m = re.match(r"^(\d+)[_ ](.+)$", folder)
        nr = fm.get("nummer") or (m.group(1) if m else "")
        name = fm.get("name") or (m.group(2) if m else folder)
        agent = {
            "nr": str(nr).zfill(2) if str(nr).isdigit() else str(nr),
            "name": name,
            "rolle": fm.get("rolle", ""),
            "layer": fm.get("layer", ""),
            "status": fm.get("status", "Aktiv"),
            "skills": split_list(fm.get("skills", "")),
            "subagent": fm.get("subagent", "").lower() not in ("nein", "no", "false"),
            "titel": first_heading(body),
            "pfad": rel(f),
        }
        if not agent["rolle"]:
            warnings.append({"typ": "Agent", "name": name, "text": "Im Kopfblock fehlt die Rolle."})
        agents.append(agent)

    # ---------- Skills ----------
    skills = []
    for f in sorted((ROOT / ".claude" / "skills").glob("*/SKILL.md")):
        fm, body = parse_frontmatter(read(f))
        name = fm.get("name") or f.parent.name
        desc = fm.get("description", "")
        if not desc:
            warnings.append({"typ": "Skill", "name": name, "text": "Es fehlt die description. Ohne sie erkennt Claude nicht, wann der Skill gebraucht wird."})
        if name != f.parent.name:
            warnings.append({"typ": "Skill", "name": name, "text": f"Name im Kopfblock ({name}) und Ordnername ({f.parent.name}) sind verschieden."})
        skills.append({
            "name": name,
            "description": desc,
            "pfad": rel(f),
            "usedBy": [],
        })

    skill_names = {s["name"] for s in skills}
    skill_by_name = {s["name"]: s for s in skills}

    # ---------- Subagent Dateien ----------
    wrappers = {}
    for f in sorted((ROOT / ".claude" / "agents").glob("*.md")):
        fm, _ = parse_frontmatter(read(f))
        wrappers[(fm.get("name") or f.stem).lower()] = rel(f)

    agent_keys = set()
    for a in agents:
        key = a["name"].lower()
        agent_keys.add(key)
        a["wrapper"] = wrappers.get(key, "")
        for s in a["skills"]:
            if s in skill_by_name:
                skill_by_name[s]["usedBy"].append(a["name"])
            else:
                warnings.append({"typ": "Agent", "name": a["name"], "text": f"Skill '{s}' ist eingetragen, aber es gibt keinen Ordner .claude/skills/{s}."})
        if a["subagent"] and key not in OHNE_SUBAGENT and not a["wrapper"]:
            warnings.append({"typ": "Agent", "name": a["name"], "text": "Es fehlt die Datei in .claude/agents. Ohne sie kann Claude Code den Agenten nicht als Helfer starten."})
        if not a["skills"] and key not in OHNE_SUBAGENT:
            warnings.append({"typ": "Agent", "name": a["name"], "text": "Dem Agenten ist noch kein Skill zugeordnet."})

    for key, path in wrappers.items():
        if key not in agent_keys:
            warnings.append({"typ": "Datei", "name": path, "text": "Subagent Datei ohne passende AGENT.md in Agents/."})

    for s in skills:
        if not s["usedBy"]:
            warnings.append({"typ": "Skill", "name": s["name"], "text": "Kein Agent nutzt diesen Skill. Das ist ok, wenn du ihn selbst direkt aufrufst."})

    # ---------- Besitzer / Titel ----------
    owner = ""
    for a in agents:
        if a["name"].lower() == "soul":
            fm, _ = parse_frontmatter(read(ROOT / a["pfad"]))
            owner = fm.get("besitzer", "")

    data = {
        "erzeugt": datetime.now().strftime("%d.%m.%Y %H:%M"),
        "besitzer": owner,
        "agents": agents,
        "skills": skills,
        "warnings": warnings,
    }

    OUT.write_text("window.AGENT_DATA = " + json.dumps(data, ensure_ascii=False, indent=2) + ";\n", encoding="utf-8")
    print(f"Dashboard aktualisiert: {len(agents)} Agenten, {len(skills)} Skills, {len(warnings)} Hinweise.")
    print(f"Datei: {OUT}")
    print("Oeffne dashboard/index.html mit Doppelklick.")


if __name__ == "__main__":
    sys.exit(main())
